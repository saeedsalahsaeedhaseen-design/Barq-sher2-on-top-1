package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.FileTransferStatus
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.network.PeerJsWebPortalHtml
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.components.formatSpeedArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PUiState

@Composable
fun LiveTransferScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onTogglePauseResume: () -> Unit,
    onCancelTransfer: () -> Unit,
    onRestartTransfer: () -> Unit,
    onCancelSingleFile: (String) -> Unit = {},
    onToggleSingleFilePauseResume: (String) -> Unit = {},
    onRetrySingleFile: (String) -> Unit = {},
    onAddFilesToActiveSession: (List<Uri>) -> Unit = {},
    onApproveReceiver: () -> Unit = {},
    onRejectReceiver: () -> Unit = {},
    onOpenReceivedApks: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val addMoreFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            onAddFilesToActiveSession(uris)
        }
    }

    val animatedOverallProgress by animateFloatAsState(
        targetValue = uiState.overallProgressFraction,
        animationSpec = tween(250),
        label = "overall_progress"
    )
    val overallPercent = (animatedOverallProgress * 100f).toInt().coerceIn(0, 100)
    val activeFile = uiState.activeTransferringFile

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            ScreenTopBar(
                title = "النقل الحي • برق sher",
                subtitle = uiState.connectedPeerLabel,
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Compact High-Clarity Live Telemetry Dashboard (leaves maximum vertical height for the file list)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF092235),
                                MidnightSurface,
                                Color(0xFF08241C)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(listOf(ElectricCyan, NeonEmerald)),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("live_speed_telemetry_card")
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = uiState.transferDirection.arabicTitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NeonEmerald,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Surface(
                                    color = if (uiState.isBackgroundServiceActive || uiState.isTransferRunning) {
                                        NeonEmerald.copy(alpha = 0.18f)
                                    } else {
                                        ElectricCyan.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier.testTag("background_continuity_badge")
                                ) {
                                    Text(
                                        text = if (uiState.isTransferRunning || uiState.isBackgroundServiceActive) {
                                            "⚡ مستمر بالخلفية وعند إطفاء الشاشة"
                                        } else {
                                            "جاهز للنقل"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = if (uiState.isTransferRunning || uiState.isBackgroundServiceActive) NeonEmerald else ElectricCyan,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Speed,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = formatSpeedArabic(uiState.liveOverallSpeedBytesPerSec),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = ElectricCyan,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.testTag("live_mbps_speed_text")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "المتوسط: ${formatSpeedArabic(uiState.averageSpeedBytesPerSec)} • الذروة: ${formatSpeedArabic(uiState.peakSpeedBytesPerSec)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.testTag("live_avg_and_peak_speed_text")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF07101E))
                                .border(1.4.dp, NeonEmerald, CircleShape)
                        ) {
                            Text(
                                text = "$overallPercent%",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color.White,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.testTag("live_overall_percent_text")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    LinearProgressIndicator(
                        progress = { animatedOverallProgress },
                        color = ElectricCyan,
                        trackColor = Color(0xFF070E1A),
                        strokeCap = StrokeCap.Round,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .testTag("live_overall_progress_bar")
                    )

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المنقول: ${formatBytesArabic(uiState.transferredBytes)} / ${formatBytesArabic(uiState.totalBytes)}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = Color.White,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("live_transferred_total_bytes_text")
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "المتبقي: ${uiState.formattedEtaLabel}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.testTag("live_eta_text")
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = buildString {
                                append("الملفات المكتملة: ${uiState.completedFilesOnlyCount} / ${uiState.totalFilesOnlyCount}")
                                append(" • المتبقية: ${uiState.remainingFilesOnlyCount}")
                                if (uiState.failedFilesOnlyCount > 0) {
                                    append(" • متوقفة: ${uiState.failedFilesOnlyCount}")
                                }
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = HotspotAmber,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("live_files_counts_summary_text")
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "الكود: ${uiState.connectionCode}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    activeFile?.let { current ->
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "الملف الجاري الآن: ${current.displayPathOrName} (${current.progressPercent}%)",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = ElectricCyan,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("live_active_file_name_text")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Compact Transfer Controls Row: Pause/Resume, Cancel Session, and Restart/Resume Failed
            val canTogglePauseOrResume = uiState.isTransferRunning ||
                uiState.isPaused ||
                (uiState.transferDirection == TransferDirection.RECEIVING &&
                    uiState.files.any { it.status == FileTransferStatus.FAILED })

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Button(
                    onClick = onTogglePauseResume,
                    enabled = canTogglePauseOrResume,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isPaused) NeonEmerald else HotspotAmber
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                        .testTag("pause_resume_transfer_button")
                ) {
                    Icon(
                        imageVector = if (uiState.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = null,
                        tint = Color(0xFF1A1000),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (uiState.isPaused) "استئناف" else "إيقاف مؤقت",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1000),
                        maxLines = 1,
                        softWrap = false
                    )
                }

                OutlinedButton(
                    onClick = onCancelTransfer,
                    enabled = uiState.isTransferRunning || uiState.isSenderReady || uiState.isPaused,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                        .testTag("cancel_transfer_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Cancel,
                        contentDescription = null,
                        tint = CoralRose,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "إلغاء النقل",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = CoralRose,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                OutlinedButton(
                    onClick = onRestartTransfer,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                        .testTag("restart_transfer_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Replay,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "إعادة / إكمال",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            if (uiState.transferDirection == TransferDirection.SENDING) {
                Spacer(modifier = Modifier.height(3.dp))
                OutlinedButton(
                    onClick = { addMoreFilesLauncher.launch("*/*") },
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .testTag("add_files_to_active_session_button")
                ) {
                    Text(
                        text = "➕ إضافة ملفات جديدة إلى جلسة النقل النشطة",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = ElectricCyan,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            val hasApkInSession = uiState.files.any { it.name.endsWith(".apk", ignoreCase = true) }
            if (hasApkInSession || uiState.receivedApks.isNotEmpty()) {
                Button(
                    onClick = onOpenReceivedApks,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .testTag("open_received_apks_from_live_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Android,
                        contentDescription = null,
                        tint = Color(0xFF002418),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "فتح التطبيقات المستلمة وتثبيت حزم APK (${uiState.receivedApks.size})",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF002418),
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
            }

            // Compact Folder Transfer Summary Banner when transferring whole folder(s)
            if (uiState.activeFolderNames.isNotEmpty()) {
                val completedFilesCount = uiState.files.count { it.status == FileTransferStatus.COMPLETED }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF211709))
                        .border(1.dp, HotspotAmber.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("live_folder_summary_card")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📁 مجلد: ${uiState.activeFolderNames.joinToString(" ، ")}",
                            style = MaterialTheme.typography.labelMedium,
                            color = HotspotAmber,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$completedFilesCount / ${uiState.files.size} (${formatBytesArabic(uiState.totalBytes)})",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFFDE68A),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
                Spacer(modifier = Modifier.height(5.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "قائمة الملفات الجارية (${uiState.files.size}):",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false
                )
                Text(
                    text = "اسحب للأعلى/الأسفل لتصفح كل الملفات",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    softWrap = false
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Expanded scrollable file list occupying the majority of the screen
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("live_files_lazy_column")
            ) {
                items(
                    items = uiState.files.distinctBy { it.id },
                    key = { it.id },
                    contentType = { "transfer_file_row" }
                ) { fileItem ->
                    LiveFileProgressCard(
                        item = fileItem,
                        chunkSizeLabel = uiState.selectedChunkSize.label,
                        onTogglePauseResumeFile = { onToggleSingleFilePauseResume(fileItem.id) },
                        onCancelFile = { onCancelSingleFile(fileItem.id) },
                        onRetryFile = { onRetrySingleFile(fileItem.id) }
                    )
                }
            }
        }
    }

    uiState.incomingConnectionRequest?.let { req ->
        IncomingConnectionRequestDialog(
            request = req,
            onApprove = onApproveReceiver,
            onReject = onRejectReceiver
        )
    }
}

@Composable
private fun LiveFileProgressCard(
    item: TransferFileItem,
    chunkSizeLabel: String,
    onTogglePauseResumeFile: () -> Unit = {},
    onCancelFile: () -> Unit = {},
    onRetryFile: () -> Unit = {}
) {
    val badgeColor = Color(item.category.badgeColorHex)
    val animatedFileProgress by animateFloatAsState(
        targetValue = item.progressFraction,
        animationSpec = tween(180),
        label = "file_progress_${item.id}"
    )
    val isDone = item.status == FileTransferStatus.COMPLETED
    val isFailed = item.status == FileTransferStatus.FAILED
    val isCancelled = item.status == FileTransferStatus.CANCELLED
    val isRetrying = item.status == FileTransferStatus.RETRYING
    val isPaused = item.status == FileTransferStatus.PAUSED
    val isTransferring = item.status == FileTransferStatus.TRANSFERRING || item.status == FileTransferStatus.VERIFYING

    val statusColor = when {
        isDone -> NeonEmerald
        isFailed -> CoralRose
        isCancelled -> TextSecondary
        isRetrying || isPaused -> HotspotAmber
        isTransferring -> ElectricCyan
        else -> TextSecondary
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightCard)
            .border(
                width = if (isTransferring || isRetrying) 1.3.dp else 1.dp,
                color = when {
                    isDone -> NeonEmerald.copy(alpha = 0.7f)
                    isFailed -> CoralRose.copy(alpha = 0.8f)
                    isRetrying -> HotspotAmber.copy(alpha = 0.8f)
                    isTransferring -> ElectricCyan.copy(alpha = 0.8f)
                    else -> GlassBorder
                },
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 12.dp, vertical = 9.dp)
            .testTag("live_file_card_${item.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Row 1: Category/Status Icon + Full-Width Single-Line Filename + Compact Percentage Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(badgeColor.copy(alpha = 0.18f))
                ) {
                    Icon(
                        imageVector = when {
                            isDone -> Icons.Filled.CheckCircle
                            isFailed || isCancelled -> Icons.Filled.ErrorOutline
                            else -> categoryIcon(item.category)
                        },
                        contentDescription = item.category.arabicLabel,
                        tint = when {
                            isDone -> NeonEmerald
                            isFailed -> CoralRose
                            isCancelled -> TextSecondary
                            else -> badgeColor
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = item.displayPathOrName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .testTag("live_file_name_${item.id}")
                )

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    color = statusColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Text(
                        text = if (isDone) "100%" else "${item.progressPercent}%",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = statusColor,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Row 2: Transferred / Total Size + Speed + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = buildString {
                        if (item.isDirectory) {
                            append("مجلد فرعي")
                        } else {
                            append("${formatBytesArabic(item.transferredBytes)} / ${formatBytesArabic(item.sizeBytes)}")
                            if (item.currentSpeedBytesPerSec > 0.0 && isTransferring) {
                                append(" • ${formatSpeedArabic(item.currentSpeedBytesPerSec)}")
                            } else {
                                append(" • ${item.completedChunks}/${item.totalChunks} دفعة")
                            }
                        }
                    },
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.sp,
                    color = Color(0xFFCBD5E1),
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(6.dp))

                Surface(
                    color = statusColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.testTag("live_file_status_badge_${item.id}")
                ) {
                    Text(
                        text = item.status.arabicLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = statusColor,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(5.dp))

            // Row 3: Compact Progress Bar
            LinearProgressIndicator(
                progress = { animatedFileProgress },
                color = when {
                    isDone -> NeonEmerald
                    isFailed -> CoralRose
                    isRetrying || isPaused -> HotspotAmber
                    else -> ElectricCyan
                },
                trackColor = Color(0xFF070D19),
                strokeCap = StrokeCap.Round,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
            )

            Spacer(modifier = Modifier.height(5.dp))

            // Row 4: SHA-256 / Category Info + Action Buttons (Retry / Pause-Resume / Cancel)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (item.sha256Verified || item.sha256Expected.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Filled.VerifiedUser,
                            contentDescription = null,
                            tint = if (item.sha256Verified) NeonEmerald else ElectricCyan,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        val hashPreview = (item.sha256Actual.ifBlank { item.sha256Expected }).take(12)
                        Text(
                            text = if (item.sha256Verified) {
                                "تم التحقق (SHA-256: $hashPreview...)"
                            } else {
                                "SHA-256: $hashPreview..."
                            },
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 9.sp,
                            color = if (item.sha256Verified) NeonEmerald else TextSecondary,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Text(
                            text = "${item.category.arabicLabel} • دفعة $chunkSizeLabel",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (!isDone && !isCancelled) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        if (isFailed) {
                            Surface(
                                onClick = onRetryFile,
                                color = ElectricCyan.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(999.dp),
                                modifier = Modifier.testTag("retry_single_file_${item.id}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Replay,
                                        contentDescription = "إعادة محاولة نقل الملف",
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "إعادة المحاولة",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ElectricCyan,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }

                        val isPausedItem = item.status == FileTransferStatus.PAUSED
                        val pauseBtnColor = if (isPausedItem) NeonEmerald else HotspotAmber
                        Surface(
                            onClick = onTogglePauseResumeFile,
                            color = pauseBtnColor.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.testTag("pause_resume_single_file_${item.id}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isPausedItem) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                    contentDescription = if (isPausedItem) "استئناف نقل الملف" else "إيقاف نقل الملف مؤقتاً",
                                    tint = pauseBtnColor,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (isPausedItem) "استئناف" else "إيقاف",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = pauseBtnColor,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }

                        Surface(
                            onClick = onCancelFile,
                            color = CoralRose.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.testTag("cancel_single_file_${item.id}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Cancel,
                                    contentDescription = "إلغاء نقل الملف",
                                    tint = CoralRose,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "إلغاء",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CoralRose,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }
            }

            item.errorMessage?.let { err ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = err,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isRetrying) HotspotAmber else CoralRose,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("live_file_error_${item.id}")
                )
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebRtcPeerJsPortalScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var filePathCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val webFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        filePathCallback?.onReceiveValue(uris.toTypedArray())
        filePathCallback = null
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            ScreenTopBar(
                title = "بوابة الويب • برق sher",
                subtitle = "تعمل داخل التطبيق وعبر الرابط ${uiState.networkStatus.webPortalUrl}",
                accentColor = NeonEmerald,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
            ) {
                val htmlContent = remember(uiState.connectionCode, uiState.networkStatus.localIp) {
                    PeerJsWebPortalHtml.buildHtml(
                        defaultCode = uiState.connectionCode,
                        hostIp = uiState.networkStatus.localIp,
                        hostPort = uiState.networkStatus.port
                    )
                }

                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = true
                            settings.allowContentAccess = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            webViewClient = WebViewClient()
                            webChromeClient = object : WebChromeClient() {
                                override fun onShowFileChooser(
                                    webView: WebView?,
                                    callback: ValueCallback<Array<Uri>>?,
                                    fileChooserParams: FileChooserParams?
                                ): Boolean {
                                    filePathCallback?.onReceiveValue(null)
                                    filePathCallback = callback
                                    webFilePickerLauncher.launch(arrayOf("*/*"))
                                    return true
                                }
                            }
                            loadDataWithBaseURL(
                                uiState.networkStatus.webPortalUrl,
                                htmlContent,
                                "text/html",
                                "UTF-8",
                                null
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        CopyrightFooter()
    }
}
