package com.example.network

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.model.BluetoothPeerDevice
import com.example.model.BluetoothState
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.TransferFileItem
import com.example.util.Sha256Util
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

/**
 * Manages Bluetooth Classic (RFCOMM) discovery, pairing, session handshake exchange,
 * and direct fallback file streaming for Barq P2P.
 *
 * Design principles:
 * - Never claims Bluetooth is faster than Wi-Fi: Wi-Fi / Hotspot is always recommended and used
 *   automatically in AUTO_SMART mode for high-speed data transfer (up to 80+ MB/s), while Bluetooth
 *   excels at zero-configuration nearby discovery, pairing, session code exchange, and small-file fallback.
 * - Handles Android 12+ (BLUETOOTH_SCAN, BLUETOOTH_CONNECT, BLUETOOTH_ADVERTISE) and legacy permissions cleanly.
 */
class BluetoothP2PManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onStateChanged: (BluetoothState, String?) -> Unit,
    private val onDevicesUpdated: (List<BluetoothPeerDevice>) -> Unit,
    private val onHandshakeReceivedFromPeer: (
        hostIp: String,
        port: Int,
        sessionCode: String,
        sessionId: String,
        peerName: String,
        peerBtAddress: String
    ) -> Unit
) {
    companion object {
        private const val LOG_TAG = "BarqBluetoothP2P"
        const val SERVICE_NAME = "BarqP2P_RFCOMM"
        val BARQ_BT_UUID: UUID = UUID.fromString("00001101-b471-4000-8000-00805f9b34fb")
        private const val BT_STREAM_BUFFER_BYTES = 64 * 1024

        fun requiredPermissions(): Array<String> {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE
                )
            } else {
                arrayOf(
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            }
        }

        fun hasBluetoothPermissions(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
            }
        }

        /**
         * Core stream-based Bluetooth protocol server handler (used by both BluetoothServerSocket
         * and local socket-pair unit tests).
         *
         * Supported commands:
         * 1. "HANDSHAKE|<clientName>" -> responds with JSON containing session handshake & file manifest
         * 2. "STREAM|<fileId>|<offset>" -> streams raw file bytes from offset to EOF
         */
        fun handleServerConnectionStreams(
            context: Context,
            input: InputStream,
            output: OutputStream,
            localIp: String,
            localPort: Int,
            sessionCode: String,
            sessionId: String,
            senderDeviceName: String,
            filesProvider: () -> List<TransferFileItem>,
            onBytesServed: (fileId: String, bytesCount: Long) -> Unit = { _, _ -> }
        ) {
            val dis = DataInputStream(BufferedInputStream(input, BT_STREAM_BUFFER_BYTES))
            val dos = DataOutputStream(BufferedOutputStream(output, BT_STREAM_BUFFER_BYTES))
            val commandLine = dis.readUTF()

            if (commandLine.startsWith("HANDSHAKE")) {
                val files = filesProvider()
                val filesArr = JSONArray()
                for (f in files) {
                    val obj = JSONObject().apply {
                        put("id", f.id)
                        put("name", f.name)
                        put("relativePath", f.relativePath)
                        put("rootFolderName", f.rootFolderName)
                        put("folderBatchId", f.folderBatchId)
                        put("isDirectory", f.isDirectory)
                        put("sizeBytes", f.sizeBytes)
                        put("category", f.category.name)
                        put("totalChunks", f.totalChunks)
                        put("sha256", f.sha256Expected)
                    }
                    filesArr.put(obj)
                }
                val responseJson = JSONObject().apply {
                    put("status", "OK")
                    put("qrPayload", "BARQP2P|$localIp|$localPort|$sessionCode|$sessionId")
                    put("hostIp", localIp)
                    put("port", localPort)
                    put("sessionCode", sessionCode)
                    put("sessionId", sessionId)
                    put("senderDeviceName", senderDeviceName)
                    put("files", filesArr)
                }
                dos.writeUTF(responseJson.toString())
                dos.flush()
            } else if (commandLine.startsWith("STREAM|")) {
                val parts = commandLine.split("|")
                val fileId = parts.getOrNull(1).orEmpty()
                val offset = parts.getOrNull(2)?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
                val targetItem = filesProvider().firstOrNull { it.id == fileId }
                if (targetItem == null) {
                    dos.writeLong(-1L)
                    dos.flush()
                    return
                }
                if (targetItem.isDirectory || targetItem.sizeBytes == 0L) {
                    dos.writeLong(0L)
                    dos.flush()
                    return
                }
                val remaining = (targetItem.sizeBytes - offset).coerceAtLeast(0L)
                dos.writeLong(remaining)
                dos.flush()

                val buf = ByteArray(BT_STREAM_BUFFER_BYTES)
                val localFile = targetItem.localFile
                if (localFile != null && localFile.exists() && localFile.canRead()) {
                    RandomAccessFile(localFile, "r").use { raf ->
                        if (offset > 0L) raf.seek(offset)
                        var left = remaining
                        while (left > 0L) {
                            val toRead = minOf(buf.size.toLong(), left).toInt()
                            val r = raf.read(buf, 0, toRead)
                            if (r <= 0) break
                            dos.write(buf, 0, r)
                            left -= r
                            onBytesServed(fileId, r.toLong())
                        }
                    }
                } else if (targetItem.uri != null) {
                    context.contentResolver.openInputStream(targetItem.uri)?.use { uIn ->
                        if (offset > 0L) uIn.skip(offset)
                        var left = remaining
                        while (left > 0L) {
                            val toRead = minOf(buf.size.toLong(), left).toInt()
                            val r = uIn.read(buf, 0, toRead)
                            if (r <= 0) break
                            dos.write(buf, 0, r)
                            left -= r
                            onBytesServed(fileId, r.toLong())
                        }
                    }
                }
                dos.flush()
            }
        }

        /**
         * Exchanges a HANDSHAKE over a connected stream pair and parses the Sender's session details
         * and manifest list.
         */
        fun performClientHandshakeOverStreams(
            input: InputStream,
            output: OutputStream,
            clientDeviceName: String
        ): JSONObject {
            val dos = DataOutputStream(BufferedOutputStream(output, 8192))
            val dis = DataInputStream(BufferedInputStream(input, 16384))
            dos.writeUTF("HANDSHAKE|$clientDeviceName")
            dos.flush()
            val rawResponse = dis.readUTF()
            return JSONObject(rawResponse)
        }

        /**
         * Downloads a single file over a connected Bluetooth stream pair with real speed measurement
         * and on-the-fly SHA-256 verification.
         */
        fun downloadSingleFileOverBluetoothStreams(
            item: TransferFileItem,
            input: InputStream,
            output: OutputStream,
            destFile: File,
            onProgress: (transferredBytes: Long, speedBytesPerSec: Double) -> Unit
        ): Pair<Boolean, String> {
            destFile.parentFile?.mkdirs()
            if (item.isDirectory) {
                destFile.mkdirs()
                return true to Sha256Util.EMPTY_DIR_SHA256
            }
            val dos = DataOutputStream(BufferedOutputStream(output, BT_STREAM_BUFFER_BYTES))
            val dis = DataInputStream(BufferedInputStream(input, BT_STREAM_BUFFER_BYTES))
            dos.writeUTF("STREAM|${item.id}|0")
            dos.flush()

            val expectedRemaining = dis.readLong()
            if (expectedRemaining < 0L) {
                return false to "الملف غير موجود لدى المرسل عبر البلوتوث"
            }
            if (expectedRemaining == 0L) {
                destFile.writeBytes(ByteArray(0))
                return true to Sha256Util.EMPTY_BYTES_SHA256
            }

            val partFile = File(destFile.parentFile ?: destFile, "${destFile.name}.bt.part")
            val digest = MessageDigest.getInstance("SHA-256")
            val startNano = System.nanoTime()
            var received = 0L
            val buf = ByteArray(BT_STREAM_BUFFER_BYTES)

            RandomAccessFile(partFile, "rw").use { raf ->
                raf.setLength(0L)
                while (received < expectedRemaining) {
                    val toRead = minOf(buf.size.toLong(), expectedRemaining - received).toInt()
                    val r = dis.read(buf, 0, toRead)
                    if (r <= 0) break
                    raf.write(buf, 0, r)
                    digest.update(buf, 0, r)
                    received += r
                    val elapsedSec = max(0.001, (System.nanoTime() - startNano) / 1_000_000_000.0)
                    onProgress(received, received.toDouble() / elapsedSec)
                }
            }

            if (received != expectedRemaining) {
                partFile.delete()
                return false to "انقطع اتصال البلوتوث قبل اكتمال الملف ($received / $expectedRemaining بايت)"
            }
            val shaHex = Sha256Util.bytesToHex(digest.digest())
            if (item.sha256Expected.isNotBlank() && !item.sha256Expected.equals(shaHex, ignoreCase = true)) {
                partFile.delete()
                return false to "فشل التحقق من بصمة SHA-256 عبر البلوتوث"
            }
            if (destFile.exists()) destFile.delete()
            if (!partFile.renameTo(destFile)) {
                partFile.copyTo(destFile, overwrite = true)
                partFile.delete()
            }
            return true to shaHex
        }
    }

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val discoveredMap = ConcurrentHashMap<String, BluetoothPeerDevice>()
    private var acceptServerJob: Job? = null
    private var serverSocket: BluetoothServerSocket? = null
    private var receiverRegistered = false

    private val btReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            when (action) {
                BluetoothDevice.ACTION_FOUND -> {
                    if (!hasBluetoothPermissions(context)) return
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    if (device != null && !device.address.isNullOrBlank()) {
                        val name = runCatching { device.name.orEmpty() }.getOrDefault("")
                        val paired = runCatching { device.bondState == BluetoothDevice.BOND_BONDED }.getOrDefault(false)
                        discoveredMap[device.address] = BluetoothPeerDevice(
                            name = name,
                            address = device.address,
                            isPaired = paired,
                            rssi = if (rssi != Short.MIN_VALUE.toInt()) rssi else 0
                        )
                        emitSortedDevices()
                    }
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    refreshPairedAndDiscoveredDevices()
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    if (bluetoothAdapter?.isEnabled == true) {
                        onStateChanged(BluetoothState.READY, null)
                    }
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    when (state) {
                        BluetoothAdapter.STATE_ON -> {
                            onStateChanged(BluetoothState.READY, "تم تفعيل البلوتوث بنجاح")
                            refreshPairedAndDiscoveredDevices()
                        }
                        BluetoothAdapter.STATE_OFF -> {
                            onStateChanged(BluetoothState.DISABLED, "تم إيقاف البلوتوث")
                        }
                    }
                }
            }
        }
    }

    fun inspectBluetoothState(): BluetoothState {
        val adapter = bluetoothAdapter ?: return BluetoothState.UNSUPPORTED
        if (!hasBluetoothPermissions(context)) {
            return BluetoothState.PERMISSION_REQUIRED
        }
        return if (adapter.isEnabled) BluetoothState.READY else BluetoothState.DISABLED
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedAndDiscoveredDevices() {
        val adapter = bluetoothAdapter
        if (adapter == null) {
            onStateChanged(BluetoothState.UNSUPPORTED, null)
            return
        }
        if (!hasBluetoothPermissions(context)) {
            onStateChanged(BluetoothState.PERMISSION_REQUIRED, null)
            return
        }
        if (!adapter.isEnabled) {
            onStateChanged(BluetoothState.DISABLED, null)
            return
        }
        registerReceiverIfNeeded()
        try {
            val bonded = adapter.bondedDevices.orEmpty()
            for (dev in bonded) {
                val addr = dev.address ?: continue
                val devName = runCatching { dev.name.orEmpty() }.getOrDefault("")
                discoveredMap[addr] = BluetoothPeerDevice(
                    name = devName,
                    address = addr,
                    isPaired = true,
                    rssi = discoveredMap[addr]?.rssi ?: 0
                )
            }
            emitSortedDevices()
            onStateChanged(
                if (adapter.isDiscovering) BluetoothState.SCANNING else BluetoothState.READY,
                null
            )
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException reading bondedDevices: ${se.message}")
            onStateChanged(BluetoothState.PERMISSION_REQUIRED, "يرجى منح صلاحية البلوتوث لعرض الأجهزة المقترنة")
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "Error refreshing Bluetooth devices: ${t.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun startDeviceDiscovery() {
        val adapter = bluetoothAdapter
        if (adapter == null) {
            onStateChanged(BluetoothState.UNSUPPORTED, "هذا الجهاز لا يحتوي على محول بلوتوث")
            return
        }
        if (!hasBluetoothPermissions(context)) {
            onStateChanged(BluetoothState.PERMISSION_REQUIRED, "يرجى منح صلاحية البحث والاتصال عبر البلوتوث")
            return
        }
        if (!adapter.isEnabled) {
            onStateChanged(BluetoothState.DISABLED, "البلوتوث مغلق؛ يرجى تفعيله أولاً")
            return
        }
        registerReceiverIfNeeded()
        refreshPairedAndDiscoveredDevices()
        try {
            if (adapter.isDiscovering) {
                adapter.cancelDiscovery()
            }
            val started = adapter.startDiscovery()
            if (started) {
                onStateChanged(BluetoothState.SCANNING, "جاري البحث عن أجهزة البلوتوث القريبة...")
            } else {
                onStateChanged(BluetoothState.READY, "تم تحديث قائمة أجهزة البلوتوث المقترنة")
            }
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException starting Bluetooth discovery: ${se.message}")
            onStateChanged(BluetoothState.PERMISSION_REQUIRED, "يلزم منح إذن البلوتوث للبحث عن الأجهزة")
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Error starting Bluetooth discovery: ${t.message}")
            onStateChanged(BluetoothState.ERROR, "تعذر بدء البحث عبر البلوتوث: ${t.localizedMessage ?: ""}")
        }
    }

    @SuppressLint("MissingPermission")
    fun pairWithDevice(peer: BluetoothPeerDevice) {
        val adapter = bluetoothAdapter ?: return
        if (!hasBluetoothPermissions(context)) {
            onStateChanged(BluetoothState.PERMISSION_REQUIRED, "يلزم منح صلاحية البلوتوث للاقتران")
            return
        }
        try {
            if (adapter.isDiscovering) adapter.cancelDiscovery()
            val remote = adapter.getRemoteDevice(peer.address)
            if (remote.bondState == BluetoothDevice.BOND_BONDED) {
                onStateChanged(BluetoothState.READY, "الجهاز «${peer.displayName}» مقترن بالفعل وجاهز للاتصال")
            } else {
                val initiated = remote.createBond()
                if (initiated) {
                    onStateChanged(BluetoothState.CONNECTING, "جاري طلب الاقتران مع «${peer.displayName}»...")
                } else {
                    openSystemBluetoothSettings()
                }
            }
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "Error pairing with ${peer.address}: ${t.message}")
            openSystemBluetoothSettings()
        }
    }

    fun openSystemBluetoothSettings() {
        try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    /**
     * Starts an RFCOMM Server on the Sender device so any nearby Receiver can either:
     * 1. Exchange the session handshake (BARQP2P|ip|port|code|sessionId) over Bluetooth and seamlessly
     *    upgrade to high-speed Wi-Fi / Hotspot transfer, OR
     * 2. Stream files directly over Bluetooth RFCOMM if Wi-Fi is unavailable.
     */
    @SuppressLint("MissingPermission")
    fun startRfcommServer(
        localIpProvider: () -> String,
        localPortProvider: () -> Int,
        sessionCodeProvider: () -> String,
        sessionIdProvider: () -> String,
        filesProvider: () -> List<TransferFileItem>,
        onBytesServed: (fileId: String, bytesCount: Long) -> Unit
    ) {
        val adapter = bluetoothAdapter ?: return
        if (!hasBluetoothPermissions(context) || !adapter.isEnabled) return

        stopRfcommServer()
        acceptServerJob = scope.launch(Dispatchers.IO) {
            try {
                val srv = try {
                    adapter.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, BARQ_BT_UUID)
                } catch (_: Exception) {
                    adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, BARQ_BT_UUID)
                }
                serverSocket = srv
                onStateChanged(BluetoothState.LISTENING, "خادم البلوتوث المحلي نشط للاقتران السريع ونقل الجلسة")

                while (isActive) {
                    val clientSocket: BluetoothSocket = try {
                        srv.accept()
                    } catch (_: Exception) {
                        break
                    }
                    launch(Dispatchers.IO) {
                        clientSocket.use { sock ->
                            try {
                                handleServerConnectionStreams(
                                    context = context,
                                    input = sock.inputStream,
                                    output = sock.outputStream,
                                    localIp = localIpProvider(),
                                    localPort = localPortProvider(),
                                    sessionCode = sessionCodeProvider(),
                                    sessionId = sessionIdProvider(),
                                    senderDeviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
                                    filesProvider = filesProvider,
                                    onBytesServed = onBytesServed
                                )
                            } catch (t: Throwable) {
                                Log.w(LOG_TAG, "RFCOMM client handler finished/closed: ${t.message}")
                            }
                        }
                    }
                }
            } catch (se: SecurityException) {
                Log.w(LOG_TAG, "SecurityException starting RFCOMM server: ${se.message}")
            } catch (t: Throwable) {
                Log.w(LOG_TAG, "RFCOMM server stopped: ${t.message}")
            }
        }
    }

    fun stopRfcommServer() {
        acceptServerJob?.cancel()
        acceptServerJob = null
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
    }

    /**
     * Connects to a Sender's Bluetooth device, exchanges the session handshake, and notifies
     * the ViewModel so it can either connect over Wi-Fi/Hotspot (AUTO_SMART) or stream directly
     * over Bluetooth (BLUETOOTH_DIRECT).
     */
    @SuppressLint("MissingPermission")
    fun connectToPeerForHandshake(
        peer: BluetoothPeerDevice,
        onManifestAlsoFetched: (List<TransferFileItem>, String) -> Unit
    ) {
        val adapter = bluetoothAdapter
        if (adapter == null) {
            onStateChanged(BluetoothState.UNSUPPORTED, "البلوتوث غير مدعوم على هذا الجهاز")
            return
        }
        if (!hasBluetoothPermissions(context)) {
            onStateChanged(BluetoothState.PERMISSION_REQUIRED, "يرجى منح صلاحية البلوتوث للاتصال")
            return
        }
        if (!adapter.isEnabled) {
            onStateChanged(BluetoothState.DISABLED, "يرجى تشغيل البلوتوث أولاً")
            return
        }

        scope.launch(Dispatchers.IO) {
            onStateChanged(BluetoothState.CONNECTING, "جاري الاتصال عبر البلوتوث بـ «${peer.displayName}»...")
            try {
                if (adapter.isDiscovering) adapter.cancelDiscovery()
                val remoteDevice = adapter.getRemoteDevice(peer.address)
                val sock = try {
                    remoteDevice.createInsecureRfcommSocketToServiceRecord(BARQ_BT_UUID)
                } catch (_: Exception) {
                    remoteDevice.createRfcommSocketToServiceRecord(BARQ_BT_UUID)
                }

                sock.use { btSocket ->
                    btSocket.connect()
                    val json = performClientHandshakeOverStreams(
                        input = btSocket.inputStream,
                        output = btSocket.outputStream,
                        clientDeviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
                    )
                    val hostIp = json.optString("hostIp", "192.168.43.1")
                    val port = json.optInt("port", 8989)
                    val sessionCode = json.optString("sessionCode", "")
                    val sessionId = json.optString("sessionId", "")
                    val senderName = json.optString("senderDeviceName", peer.displayName)
                    val filesJson = json.optJSONArray("files") ?: JSONArray()
                    val parsedItems = mutableListOf<TransferFileItem>()
                    for (i in 0 until filesJson.length()) {
                        val obj = filesJson.getJSONObject(i)
                        val isDir = obj.optBoolean("isDirectory", false)
                        val catStr = obj.optString("category", "DOCUMENT")
                        val cat = runCatching { FileCategory.valueOf(catStr) }.getOrDefault(FileCategory.DOCUMENT)
                        parsedItems.add(
                            TransferFileItem(
                                id = obj.optString("id", "bt_$i"),
                                name = obj.optString("name", "file_$i"),
                                relativePath = obj.optString("relativePath", ""),
                                rootFolderName = obj.optString("rootFolderName", ""),
                                folderBatchId = obj.optString("folderBatchId", ""),
                                isDirectory = isDir,
                                sizeBytes = obj.optLong("sizeBytes", 0L),
                                category = cat,
                                totalChunks = max(1, obj.optInt("totalChunks", 1)),
                                status = FileTransferStatus.QUEUED,
                                sha256Expected = obj.optString("sha256", "")
                            )
                        )
                    }

                    withContext(Dispatchers.Main) {
                        onStateChanged(
                            BluetoothState.CONNECTED,
                            "تم الاقتران واستلام بيانات جلسة «$senderName» عبر البلوتوث بنجاح!"
                        )
                        if (parsedItems.isNotEmpty()) {
                            onManifestAlsoFetched(parsedItems, senderName)
                        }
                        onHandshakeReceivedFromPeer(
                            hostIp,
                            port,
                            sessionCode,
                            sessionId,
                            senderName,
                            peer.address
                        )
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (se: SecurityException) {
                Log.w(LOG_TAG, "SecurityException connecting via Bluetooth: ${se.message}")
                onStateChanged(BluetoothState.PERMISSION_REQUIRED, "تم رفض صلاحية الاتصال عبر البلوتوث")
            } catch (t: Throwable) {
                Log.w(LOG_TAG, "Error connecting to Bluetooth peer ${peer.address}: ${t.message}")
                onStateChanged(
                    BluetoothState.ERROR,
                    "تعذر الاتصال عبر البلوتوث بـ «${peer.displayName}» — تأكد من بدء جلسة الإرسال في الجهاز الآخر واقتراب الجهازين"
                )
            }
        }
    }

    /**
     * Executes a full direct Bluetooth Classic (RFCOMM) file receive session from a peer Bluetooth MAC address
     * when Wi-Fi/Hotspot is unavailable or when TransportMode.BLUETOOTH_DIRECT is explicitly chosen.
     */
    @SuppressLint("MissingPermission")
    suspend fun executeDirectBluetoothReceiveSession(
        peerAddress: String,
        downloadDir: File,
        itemsProvider: () -> List<TransferFileItem>,
        isPausedProvider: () -> Boolean,
        onFileUpdated: (
            fileId: String,
            fileSpeedBytesPerSec: Double,
            sessionSpeedBytesPerSec: Double,
            transform: (TransferFileItem) -> TransferFileItem
        ) -> Unit,
        onFileCompleted: (TransferFileItem, Double) -> Unit,
        onFileFailed: (TransferFileItem, String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val adapter = bluetoothAdapter ?: return@withContext true
        if (!hasBluetoothPermissions(context) || !adapter.isEnabled) return@withContext true
        if (adapter.isDiscovering) runCatching { adapter.cancelDiscovery() }

        val remoteDevice = try {
            adapter.getRemoteDevice(peerAddress)
        } catch (e: Exception) {
            return@withContext true
        }

        val sessionStartNano = System.nanoTime()
        var sessionTransferredBytes = 0L
        var anyFailed = false

        for (initialItem in itemsProvider()) {
            while (isPausedProvider()) {
                delay(150)
            }
            val item = itemsProvider().find { it.id == initialItem.id } ?: continue
            if (item.status == FileTransferStatus.COMPLETED || item.status == FileTransferStatus.CANCELLED) {
                continue
            }
            val destFile = if (item.relativePath.isNotBlank()) {
                File(downloadDir, item.relativePath)
            } else {
                File(downloadDir, item.name)
            }
            if (item.isDirectory) {
                destFile.mkdirs()
                var doneItem: TransferFileItem? = null
                onFileUpdated(item.id, 0.0, 0.0) { f ->
                    val d = f.copy(
                        completedChunks = f.totalChunks,
                        transferredBytes = 0L,
                        status = FileTransferStatus.COMPLETED,
                        savedPath = destFile.absolutePath,
                        sha256Actual = Sha256Util.EMPTY_DIR_SHA256,
                        sha256Verified = true
                    )
                    doneItem = d
                    d
                }
                doneItem?.let { onFileCompleted(it, 0.0) }
                continue
            }

            onFileUpdated(item.id, 0.0, 0.0) {
                it.copy(status = FileTransferStatus.TRANSFERRING, errorMessage = null)
            }

            val fileStartNano = System.nanoTime()
            try {
                val sock = try {
                    remoteDevice.createInsecureRfcommSocketToServiceRecord(BARQ_BT_UUID)
                } catch (_: Exception) {
                    remoteDevice.createRfcommSocketToServiceRecord(BARQ_BT_UUID)
                }

                sock.use { btSocket ->
                    btSocket.connect()
                    var prevFileBytes = 0L
                    val (ok, shaOrErr) = downloadSingleFileOverBluetoothStreams(
                        item = item,
                        input = btSocket.inputStream,
                        output = btSocket.outputStream,
                        destFile = destFile,
                        onProgress = { fileReceived, fileSpeed ->
                            val delta = (fileReceived - prevFileBytes).coerceAtLeast(0L)
                            prevFileBytes = fileReceived
                            sessionTransferredBytes += delta
                            val sesElapsed = max(0.001, (System.nanoTime() - sessionStartNano) / 1_000_000_000.0)
                            val sesSpeed = sessionTransferredBytes.toDouble() / sesElapsed
                            onFileUpdated(item.id, fileSpeed, sesSpeed) { f ->
                                f.copy(
                                    transferredBytes = fileReceived,
                                    currentSpeedBytesPerSec = fileSpeed,
                                    status = FileTransferStatus.TRANSFERRING
                                )
                            }
                        }
                    )
                    if (!ok) {
                        anyFailed = true
                        onFileUpdated(item.id, 0.0, 0.0) { f ->
                            f.copy(status = FileTransferStatus.FAILED, errorMessage = shaOrErr)
                        }
                        onFileFailed(item, shaOrErr)
                    } else {
                        val fileElapsed = max(0.001, (System.nanoTime() - fileStartNano) / 1_000_000_000.0)
                        val avgFileSpeed = item.sizeBytes.toDouble() / fileElapsed
                        var doneSnap: TransferFileItem? = null
                        onFileUpdated(item.id, avgFileSpeed, avgFileSpeed) { f ->
                            val d = f.copy(
                                completedChunks = f.totalChunks,
                                transferredBytes = f.sizeBytes,
                                currentSpeedBytesPerSec = avgFileSpeed,
                                status = FileTransferStatus.COMPLETED,
                                savedPath = destFile.absolutePath,
                                sha256Actual = shaOrErr,
                                sha256Verified = true
                            )
                            doneSnap = d
                            d
                        }
                        doneSnap?.let { onFileCompleted(it, avgFileSpeed) }
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                anyFailed = true
                val msg = "انقطع اتصال البلوتوث أثناء نقل ${item.name}: ${t.localizedMessage ?: "خطأ اتصال"}"
                onFileUpdated(item.id, 0.0, 0.0) { f ->
                    f.copy(status = FileTransferStatus.FAILED, errorMessage = msg)
                }
                onFileFailed(item, msg)
                onStateChanged(BluetoothState.DISCONNECTED, msg)
                break
            }
        }
        anyFailed
    }

    private fun emitSortedDevices() {
        val sorted = discoveredMap.values.sortedWith(
            compareByDescending<BluetoothPeerDevice> { it.isPaired }
                .thenByDescending { it.name.isNotBlank() }
                .thenByDescending { it.rssi }
                .thenBy { it.displayName.lowercase() }
        )
        onDevicesUpdated(sorted)
    }

    private fun registerReceiverIfNeeded() {
        if (receiverRegistered) return
        try {
            val filter = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(btReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(btReceiver, filter)
            }
            receiverRegistered = true
        } catch (_: Exception) {
        }
    }

    fun cleanup() {
        stopRfcommServer()
        if (receiverRegistered) {
            try {
                context.unregisterReceiver(btReceiver)
            } catch (_: Exception) {
            }
            receiverRegistered = false
        }
    }
}
